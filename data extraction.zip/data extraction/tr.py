import openpyxl
from bs4 import BeautifulSoup
import requests


def extract_text(url, filename):
    """Extracts article title and text from a given URL and saves them to a text file.

    Args:
        url (str): The URL of the article.
        filename (str): The filename (URL_ID) to save the extracted content.
    """

    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.content, "html.parser")

        # Find logic to identify article title and text elements in your specific case
        # Replace with appropriate selectors based on website structure
        title_element = soup.find(
            "h1", class_="entry-title"
        )  # Replace with actual selector
        text_elements = soup.find_all(
            "p"
        )  # Replace with actual selector for article body paragraphs

        if title_element:
            title = title_element.text.strip()
        else:
            title = "Title Not Found"

        text = ""
        for element in text_elements:
            text += element.text.strip() + "\n"  # Add newline between paragraphs

        with open(f"{filename}.txt", "w", encoding="utf-8") as f:
            f.write(f"{title}\n\n{text}")

        print(f"Successfully extracted text for URL: {url}")

    except Exception as e:
        print(f"Error processing URL {url}: {e}")


def process_articles(filename):
    """Processes articles from an Excel file, extracts text, and saves them.

    Args:
        filename (str): The name of the Excel file containing URLs and IDs.
    """

    wb = openpyxl.load_workbook("input.xlsx")
    sheet = wb.active  # Assuming all URLs are in the first sheet

    # Identify columns containing URL and ID (adjust based on your sheet layout)
    url_col = 1  # Assuming URLs are in the first column (index 0)
    id_col = 2  # Assuming IDs are in the second column (index 1)

    for row in sheet.iter_rows(min_row=2):  # Skip the header row
        url = row[url_col - 1].value  # Adjust index for column offset
        url_id = row[id_col - 1].value  # Adjust index for column offset

        if url:
            extract_text(url, url_id)


if __name__ == "__main__":
    process_articles("Input.xlsx")  # Replace with your Excel file name
