import requests
from bs4 import BeautifulSoup
from textstat.textstat import textstat
import pandas as pd
import re
import datetime


def extract_text(url):
    """Extracts article title and text from a given URL."""
    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")
    title_element = soup.find("h1", class_="entry-title")
    text_elements = soup.find_all("p")

    if title_element:
        title = title_element.text.strip()
    else:
        title = "Title Not Found"

    text = ""
    for element in text_elements:
        text += element.text.strip() + "\n"

    return title, text


def analyze_text(text):
    """Calculates sentiment and readability metrics for a given text."""
    # Sentiment analysis (uncomment if using NLTK)
    # from nltk.sentiment.vader import SentimentIntensityAnalyzer
    # analyzer = SentimentIntensityAnalyzer()
    # sentiment = analyzer.polarity_scores(text)

    avg_sentence_length = textstat.avg_sentence_length(text)
    complex_word_pct = textstat.difficult_words(text) / len(text.split()) * 100
    fog_index = textstat.gunning_fog(text)
    avg_words_per_sentence = textstat.avg_sentence_length(text)
    complex_word_count = textstat.difficult_words(text)
    word_count = len(text.split())
    syllables_per_word = textstat.syllable_count(text) / word_count
    personal_pronouns = len(
        re.findall(
            r"\b(I|me|my|you|he|him|his|she|her|hers|it|its|we|us|our|they|them|their)\b",
            text,
            re.IGNORECASE,
        )
    )
    words = text.split()
    avg_word_length = sum(len(word) for word in words) / len(words)

    metrics = {
        "avg_sentence_length": avg_sentence_length,
        "complex_word_pct": complex_word_pct,
        "fog_index": fog_index,
        "avg_words_per_sentence": avg_words_per_sentence,
        "complex_word_count": complex_word_count,
        "word_count": word_count,
        "syllables_per_word": syllables_per_word,
        "personal_pronouns": personal_pronouns,
        "avg_word_length": avg_word_length,
    }

    return metrics


def process_articles(urls):
    """Processes a list of URLs, extracts text, analyzes it, and writes results"""
    data = []
    for i, url in enumerate(urls):
        try:
            title, text = extract_text(url)
            metrics = analyze_text(text)
            data_row = {"URL": url, **metrics}
            data.append(data_row)
        except requests.exceptions.RequestException as e:
            print(f"Error processing URL {url}: {e}")

    df = pd.DataFrame(data)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    df.to_excel(f"output_{timestamp}.xlsx", index=False)


if __name__ == "__main__":
    urls = [
        "https://insights.blackcoffer.com/the-rise-of-the-ott-platform-and-its-impact-on-the-entertainment-industry-by-2040/"
    ]
    process_articles(urls)
